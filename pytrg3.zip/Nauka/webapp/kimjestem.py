
print(f"Witaj, nazywam się {__name__}.")
